package ui.gui;

interface MessageBoard {
  void showMessage (String message);
}